import 'package:flutter/material.dart';

import 'home_page.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({
    super.key,
  });

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  late final Animation<double> _opacity;

  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(
        milliseconds: 1200,
      ),
    );

    _opacity = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeIn,
    );

    _scale = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutBack,
    );

    _controller.forward();

    Future.delayed(
      const Duration(
        seconds: 3,
      ),
      () {
        if (!mounted) {
          return;
        }

        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
            builder: (context) {
              return const HomePage();
            },
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFE8F7FF),
              Color(0xFFF8FCFF),
              Color(0xFFE8F8E8),
            ],
          ),
        ),
        child: Stack(
          children: [
            // =========================
            // MATAHARI
            // =========================
            Positioned(
              top: 45,
              right: 170,
              child: Container(
                width: 75,
                height: 75,
                decoration: const BoxDecoration(
                  color: Color(0xFFFFD95A),
                  shape: BoxShape.circle,
                ),
              ),
            ),

            // =========================
            // AWAN KIRI
            // =========================
            const Positioned(
              top: 65,
              left: 50,
              child: _Cloud(
                width: 135,
                height: 58,
              ),
            ),

            // =========================
            // AWAN KANAN
            // =========================
            const Positioned(
              top: 125,
              right: 55,
              child: _Cloud(
                width: 150,
                height: 62,
              ),
            ),

            // =========================
            // RUMPUT
            // =========================
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: SizedBox(
                height: 110,
                child: CustomPaint(
                  painter: _GrassPainter(),
                ),
              ),
            ),

            // =========================
            // ISI SPLASH
            // =========================
            Center(
              child: AnimatedBuilder(
                animation: _controller,
                builder: (
                  context,
                  child,
                ) {
                  return Opacity(
                    opacity: _opacity.value,
                    child: Transform.scale(
                      scale: _scale.value,
                      child: child,
                    ),
                  );
                },
                child: Container(
                  width: 520,
                  margin: const EdgeInsets.all(24),
                  padding: const EdgeInsets.fromLTRB(
                    32,
                    35,
                    32,
                    38,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(
                      .96,
                    ),
                    borderRadius:
                        BorderRadius.circular(35),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(
                          .08,
                        ),
                        blurRadius: 30,
                        offset: const Offset(
                          0,
                          15,
                        ),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // =========================
                      // GAMBAR ANAK SD
                      // =========================
                      SizedBox(
                        width: 190,
                        height: 190,
                        child: Image.asset(
                          'assets/anak sd angkat tangan.jpeg',
                          fit: BoxFit.contain,
                          errorBuilder: (
                            context,
                            error,
                            stackTrace,
                          ) {
                            return const Icon(
                              Icons.school_rounded,
                              size: 120,
                              color: Color(
                                0xFF4F8FF7,
                              ),
                            );
                          },
                        ),
                      ),

                      const SizedBox(
                        height: 8,
                      ),

                      // =========================
                      // SAPAAN
                      // =========================
                      const Text(
                        'Halo, Teman Belajar!',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight:
                              FontWeight.w900,
                          color: Color(
                            0xFF243B5A,
                          ),
                        ),
                      ),

                      const SizedBox(
                        height: 9,
                      ),

                      const Text(
                        'Selamat datang di Belajar Ceria',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight:
                              FontWeight.w800,
                          color: Color(
                            0xFF4F8FF7,
                          ),
                        ),
                      ),

                      const SizedBox(
                        height: 8,
                      ),

                      const Text(
                        'Yuk belajar sambil bermain '
                        'dan raih nilai terbaikmu!',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(
                            0xFF71869A,
                          ),
                          fontWeight:
                              FontWeight.w600,
                          height: 1.4,
                        ),
                      ),

                      const SizedBox(
                        height: 25,
                      ),

                      const SizedBox(
                        width: 30,
                        height: 30,
                        child:
                            CircularProgressIndicator(
                          strokeWidth: 3,
                          color: Color(
                            0xFF4F8FF7,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ======================================================
// CLOUD
// ======================================================

class _Cloud extends StatelessWidget {
  final double width;

  final double height;

  const _Cloud({
    required this.width,
    required this.height,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          Positioned(
            bottom: 0,
            left: width * .08,
            child: Container(
              width: width * .82,
              height: height * .55,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(
                  .80,
                ),
                borderRadius:
                    BorderRadius.circular(40),
              ),
            ),
          ),
          Positioned(
            bottom: height * .20,
            left: width * .25,
            child: Container(
              width: width * .35,
              height: height * .65,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(
                  .85,
                ),
                shape: BoxShape.circle,
              ),
            ),
          ),
          Positioned(
            bottom: height * .20,
            right: width * .20,
            child: Container(
              width: width * .30,
              height: height * .55,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(
                  .85,
                ),
                shape: BoxShape.circle,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ======================================================
// GRASS
// ======================================================

class _GrassPainter extends CustomPainter {
  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    final paint = Paint()
      ..color = const Color(
        0xFF9AD66D,
      )
      ..style = PaintingStyle.fill;

    final path = Path();

    path.moveTo(
      0,
      size.height * .35,
    );

    for (
      double x = 0;
      x <= size.width;
      x += 80
    ) {
      path.quadraticBezierTo(
        x + 40,
        size.height * .05,
        x + 80,
        size.height * .35,
      );
    }

    path.lineTo(
      size.width,
      size.height,
    );

    path.lineTo(
      0,
      size.height,
    );

    path.close();

    canvas.drawPath(
      path,
      paint,
    );
  }

  @override
  bool shouldRepaint(
    covariant CustomPainter oldDelegate,
  ) {
    return false;
  }
}